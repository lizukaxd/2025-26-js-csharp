using System.Collections.Generic;
using System.Linq;

public class Tankonyvrendeles
{
    public Osztaly Osztaly { get; set; }
    public List<Tankonyv> Konyvek { get; set; }

    public Tankonyvrendeles(Osztaly osztaly)
    {
        Osztaly = osztaly;
        Konyvek = new List<Tankonyv>();
    }

    public int OsszAr()
    {
        return Konyvek.Sum(k => k.Ar) * Osztaly.Letszam;
    }

    public override string ToString()
    {
        string konyvLista = string.Join(", ", Konyvek.Select(k => k.Cim));
        return $"{Osztaly.Nev}: {konyvLista}";
    }
}
