public class Tankonyv
{
    public string Cim {get; set;}
    public int Ar {get; set;}
    public int Evfolyam {get; set;}

    public Tankonyv(string cim, int ar, int evfolyam)
    {
        Cim = cim;
        Ar = ar;
        Evfolyam = evfolyam;

    }

    public override string ToString()
    {
        return $"{Cim}, {Ar} Ft, {Evfolyam}. évfolyam";
    }
}

