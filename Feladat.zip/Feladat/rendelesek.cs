using System.Collections.Generic;
using System.IO;

public class Rendelesek
{
    public List<Tankonyvrendeles> Lista { get; set; }

    public Rendelesek(string fajlNev)
    {
        Lista = new List<Tankonyvrendeles>();
        Beolvas(fajlNev);
    }

    private void Beolvas(string fajlNev)
    {
        using (StreamReader sr = new StreamReader(fajlNev))
        {
            while (!sr.EndOfStream)
            {
                string sor = sr.ReadLine();
                if (string.IsNullOrWhiteSpace(sor)) continue;

                string[] adat = sor.Split(';');
                Osztaly osztaly = new Osztaly(adat[0], int.Parse(adat[1]), adat[2]);
                Tankonyvrendeles rendeles = new Tankonyvrendeles(osztaly);

                while (true)
                {
                    string konyvSor = sr.ReadLine();
                    if (konyvSor == "#") break;

                    string[] k = konyvSor.Split(';');
                    Tankonyv t = new Tankonyv(k[0], int.Parse(k[1]), int.Parse(k[2]));
                    rendeles.Konyvek.Add(t);
                }

                Lista.Add(rendeles);
            }
        }
    }
}
