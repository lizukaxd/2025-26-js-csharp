using System;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        Rendelesek r = new Rendelesek("rendelesek 1.txt");

        foreach (var rendeles in r.Lista)
        {
            Console.WriteLine(rendeles);
            Console.WriteLine("Összár: " + rendeles.OsszAr() + " Ft");
            Console.WriteLine();
        }
    }
}
