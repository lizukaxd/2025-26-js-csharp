public class Osztaly
{
    public string Nev {get; set;}
    public int Letszam {get;set;}
    public string Tanev {get; set;}

    public Osztaly(string nev, int letszam, string tanev)
    {
        Nev = nev;
        Letszam = letszam;
        Tanev = tanev;
    }

    public override string ToString()
    {
        return $"{Nev}, {Letszam} fő, {Tanev}";
    }
}

